const organizationRepository = require("../repositories/organizationRepository");
const notificationService = require("./notificationService");

// ==============================
// Create Organization
// ==============================
const createOrganization = async (organizationData) => {

    // Check if organization email already exists
    const existingOrganization =
        await organizationRepository.getOrganizationByEmail(
            organizationData.email
        );

    if (existingOrganization) {
        const error = new Error(
            "Organization email already exists"
        );

        error.statusCode = 409;

        throw error;
    }

    return await organizationRepository.createOrganization(
        organizationData
    );
};


// ==============================
// Get All Organizations
// ==============================
const getOrganizations = async () => {

    return await organizationRepository.getOrganizations();

};


// ==============================
// Get Organization By ID
// ==============================
const getOrganizationById = async (id) => {

    return await organizationRepository.getOrganizationById(id);

};


// ==============================
// Update Organization
// ==============================
const updateOrganization = async (id, organizationData) => {

    return await organizationRepository.updateOrganization(
        id,
        organizationData
    );

};


// ==============================
// Delete Organization
// ==============================
const deleteOrganization = async (id) => {

    return await organizationRepository.deleteOrganization(id);

};


// ==============================
// Assign User To Organization
// ==============================
const assignUserToOrganization = async (
    organizationId,
    userId,
    role
) => {

    const result = await organizationRepository.assignUserToOrganization(
        organizationId,
        userId,
        role
    );
    
    const organization = await organizationRepository.getOrganizationById(organizationId);
    if (organization) {
        await notificationService.userAddedToOrganization(organization, userId, role);
    }

    return result;
};


// ==============================
// Remove User From Organization
// ==============================
const removeUserFromOrganization = async (
    organizationId,
    userId
) => {
    
    const organization = await organizationRepository.getOrganizationById(organizationId);
    
    const result = await organizationRepository.removeUserFromOrganization(
        organizationId,
        userId
    );
    
    if (organization) {
        await notificationService.userRemovedFromOrganization(organization, userId);
    }

    return result;
};


// ==============================
// Transfer Organization Owner
// ==============================
const transferOrganizationOwner = async (
    organizationId,
    newOwnerId
) => {

    return await organizationRepository.transferOrganizationOwner(
        organizationId,
        newOwnerId
    );

};


// ==============================
// Export
// ==============================
module.exports = {

    createOrganization,
    getOrganizations,
    getOrganizationById,
    updateOrganization,
    deleteOrganization,
    assignUserToOrganization,
    removeUserFromOrganization,
    transferOrganizationOwner

};